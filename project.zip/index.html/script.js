document.addEventListener("DOMContentLoaded", () => {
    // 1. إعداد التاريخ الحالي كقيمة افتراضية
    document.getElementById("dateAdded").value = new Date().toISOString().split('T')[0];

    // 2. ربط الدوال بالأزرار وعناصر التحكم
    document.getElementById("saveBtn").onclick = saveStudent;
    document.getElementById("clearBtn").onclick = clearForm;
    document.getElementById("excelBtn").onclick = exportToExcel;
    document.getElementById("pdfBtn").onclick = exportToPDF;
    document.getElementById("printBtn").onclick = printTable;

    // 3. ربط دوال التصفية والبحث
    document.getElementById("searchInput").oninput = filterByName;
    document.getElementById("gradeFilter").onchange = filterByGrade;

    // 4. تحميل البيانات عند بدء تشغيل الصفحة
    loadFromLocalStorage();
});

// ====================================================
// FUNCTIONS FOR CRUD OPERATIONS
// ====================================================

/**
 * حفظ بيانات طالب جديد إلى الجدول والتخزين المحلي.
 */
function saveStudent() {
    const number = document.getElementById("studentNumber").value.trim();
    const name = document.getElementById("studentName").value.trim();
    const grade = document.getElementById("grade").value;
    const date = document.getElementById("dateAdded").value;
    const card = document.getElementById("cardNumber").value.trim();

    if (!number || !name || !grade || !date || !card) {
        alert("يرجى ملء جميع الحقول المطلوبة.");
        return;
    }

    // إضافة الصف للجدول
    addRowToTable({ number, name, grade, date, card });

    clearForm();
    saveToLocalStorage(); // حفظ البيانات الجديدة
}

/**
 * دالة مساعدة لإضافة صف إلى الجدول (تستخدم للحفظ وللتحميل من التخزين).
 */
function addRowToTable(studentData) {
    const tableBody = document.querySelector("#studentTable tbody");
    const row = tableBody.insertRow();

    row.insertCell(0).innerText = studentData.number;
    row.insertCell(1).innerText = studentData.name;
    row.insertCell(2).innerText = studentData.grade;
    row.insertCell(3).innerText = studentData.date;
    row.insertCell(4).innerText = studentData.card;

    // إضافة زر الحذف
    const deleteCell = row.insertCell(5);
    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "حذف";
    deleteBtn.className = "delete-btn";
    
    // ربط دالة الحذف بالزر
    deleteBtn.onclick = () => {
        // حذف الصف وإعادة حفظ البيانات
        tableBody.deleteRow(row.rowIndex - 1); 
        saveToLocalStorage();
    };
    deleteCell.appendChild(deleteBtn);
}

/**
 * مسح حقول النموذج وتعيين التاريخ الحالي.
 */
function clearForm() {
    document.getElementById("studentForm").reset();
    document.getElementById("dateAdded").value = new Date().toISOString().split('T')[0];
}

// ====================================================
// FUNCTIONS FOR FILTERS AND SEARCH
// ====================================================

/**
 * تصفية الصفوف حسب اسم الطالب.
 */
function filterByName() {
    const keyword = document.getElementById("searchInput").value.toLowerCase();
    const rows = document.querySelectorAll("#studentTable tbody tr");
    
    rows.forEach(row => {
        const name = row.cells[1].innerText.toLowerCase();
        // إخفاء الصف إذا كان لا يتضمن كلمة البحث
        const isVisible = name.includes(keyword);
        row.style.display = isVisible ? "" : "none";
    });
}

/**
 * تصفية الصفوف حسب الصف المدرسي المحدد.
 */
function filterByGrade() {
    const selectedGrade = document.getElementById("gradeFilter").value;
    const rows = document.querySelectorAll("#studentTable tbody tr");
    
    rows.forEach(row => {
        const grade = row.cells[2].innerText;
        
        // إذا كان الفلتر فارغاً أو يطابق الصف، اعرض الصف
        const isVisible = selectedGrade === "" || grade === selectedGrade;
        row.style.display = isVisible ? "" : "none";
    });
}

// ====================================================
// FUNCTIONS FOR EXPORT AND PRINTING
// ====================================================

/**
 * فتح نافذة طباعة للجدول.
 */
function printTable() {
    const printWindow = window.open('', '', 'width=800,height=600');
    const tableHTML = document.getElementById("studentTable").outerHTML;
    
    printWindow.document.write(`
        <html><head><title>طباعة بيانات الطلاب</title>
        <style>table{width:100%;border-collapse:collapse;direction:rtl;}th,td{border:1px solid #999;padding:8px;text-align:center}</style>
        </head><body><h2 style="text-align:center;">بيانات الطلاب</h2>${tableHTML}</body></html>
    `);
    printWindow.document.close();
    printWindow.print();
}

/**
 * تصدير بيانات الجدول إلى ملف CSV (Excel).
 */
function exportToExcel() {
    let csv = "رقم الطالب,اسم الطالب,الصف,تاريخ الإضافة,رقم البطاقة\n";
    const rows = document.querySelectorAll("#studentTable tbody tr");
    
    rows.forEach(row => {
        // استثناء عمود الحذف (العمود السادس)
        const data = Array.from(row.cells).slice(0, 5).map(cell => cell.innerText.replace(/"/g, '""'));
        csv += data.join(",") + "\n";
    });
    
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "بيانات_الطلاب.csv";
    link.click();
}

/**
 * تصدير الجدول إلى PDF (باستخدام وظيفة الطباعة في المتصفح).
 */
function exportToPDF() {
    // هذه الوظيفة تعمل بنفس طريقة الطباعة، حيث نعتمد على المتصفح لاختيار "حفظ كملف PDF"
    printTable(); 
}

// ====================================================
// FUNCTIONS FOR LOCAL STORAGE
// ====================================================

/**
 * حفظ جميع البيانات الموجودة في الجدول إلى Local Storage.
 */
function saveToLocalStorage() {
    const students = [];
    const rows = document.querySelectorAll("#studentTable tbody tr");
    
    rows.forEach(row => {
        const data = Array.from(row.cells).slice(0, 5).map(cell => cell.innerText);
        students.push({
            number: data[0],
            name: data[1],
            grade: data[2],
            date: data[3],
            card: data[4]
        });
    });
    // تحويل المصفوفة إلى نص JSON وحفظه
    localStorage.setItem('studentData', JSON.stringify(students));
}

/**
 * تحميل البيانات من Local Storage وإعادة بناء الجدول.
 */
function loadFromLocalStorage() {
    // الحصول على البيانات المخزنة، أو مصفوفة فارغة إذا لم يكن هناك شيء
    const students = JSON.parse(localStorage.getItem('studentData') || '[]');
    const tableBody = document.querySelector("#studentTable tbody");
    tableBody.innerHTML = ''; // مسح أي صفوف قديمة

    // إعادة إضافة كل طالب مخزن إلى الجدول
    students.forEach(student => {
        addRowToTable(student);
    });
}